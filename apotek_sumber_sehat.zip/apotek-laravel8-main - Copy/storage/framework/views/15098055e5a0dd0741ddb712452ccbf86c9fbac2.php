<?php $__env->startSection('title', 'Data Transaksi'); ?>
<?php $__env->startSection('subtitle', 'Tambah Transaksi'); ?>
<?php $__env->startSection('content'); ?>

<div class="card shadow mb-4">
    <div class="card-body">
        <p><strong>Tanggal Transaksi</strong> <?php echo e(date('Y-m-d H:i:s')); ?> </p> 
        <p><strong>Admin</strong> <?php echo e(session('username')); ?> </p>
    </div>
</div>

<div class="card shadow mb-4">
    <form action="/transaction/store" method="post">
		<?php echo csrf_field(); ?>
        <div class="card-body">
            <input type="hidden" name="date" value="<?php echo e(date('Y-m-d H:i:s')); ?>" />
            <input type="hidden" name="user_id" value="<?php echo e(session('id')); ?>" />
            <div class="form-group">
                <label class="form-label">Nama Pelanggan</label>
                <input type="text" class="form-control" name="name_customer" />
                <?php $__errorArgs = ['name_customer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"> <?php echo e($message); ?> </small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div id="drug-fields">
                <div class="row drug-field">
                    <div class="form-group col-md-6">
                        <label class="form-label">Pilih Obat</label>
                        <select class="choose-drug form-control select2" name="drug_code" onchange="updateTotal(this)">
                            <option selected disabled>Pilih salah satu</option>
                            <?php $__currentLoopData = $drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($drug->code); ?>" data-price="<?php echo e($drug->price); ?>"><?php echo e($drug->name_drug); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['drug_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"> <?php echo e($message); ?> </small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-md-3">
                        <label class="form-label">Jumlah</label>
                        <input type="number" class="form-control qty" name="qty" oninput="updateTotal(this)" min="1" required>
                        <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"> <?php echo e($message); ?> </small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-md-3">
                        <label class="form-label">Total</label>
                        <input type="text" name="total" class="total form-control" readonly>
                    </div>
                </div>
            </div>
            <button type="button" id="add-drug" class="btn btn-success">Tambah Obat</button>
            <div class="form-group mt-3">
                <label class="form-label">Total Keseluruhan</label>
                <input type="text" name="totalsemuanya" id="overall-total" class="form-control" readonly>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Buat Pesanan</button>
            <a href="/transaction" class="btn btn-secondary">Kembali</a>
        </div>
    </form>
</div>

<script>
document.getElementById('add-drug').addEventListener('click', function() {
    let drugFields = document.getElementById('drug-fields');
    let newField = document.createElement('div');
    newField.classList.add('row', 'drug-field');
    newField.innerHTML = `
        <div class="form-group col-md-6">
            <label class="form-label">Pilih Obat</label>
            <select class="choose-drug form-control select2" name="drug_code" onchange="updateTotal(this)">
                <option selected disabled>Pilih salah satu</option>
                <?php $__currentLoopData = $drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($drug->code); ?>" data-price="<?php echo e($drug->price); ?>"><?php echo e($drug->name_drug); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['drug_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"> <?php echo e($message); ?> </small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-md-3">
            <label class="form-label">Kuantitas</label>
            <input type="number" class="form-control qty" name="qty" oninput="updateTotal(this)" min="1" required>
            <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"> <?php echo e($message); ?> </small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-md-3">
            <label class="form-label">Total</label>
            <input type="text" name="total" class="total form-control" readonly>
        </div>
    `;
    drugFields.appendChild(newField);

    // Reinitialize Select2 on the new field
    $('.select2').select2();
});

function updateTotal(element) {
    let row = element.closest('.drug-field');
    let select = row.querySelector('.choose-drug');
    let qty = row.querySelector('.qty').value;
    let total = row.querySelector('.total');

    if (select && qty) {
        let price = select.options[select.selectedIndex].getAttribute('data-price');
        total.value = price * qty;
    }

    updateOverallTotal();
}

function updateOverallTotal() {
    let totalFields = document.querySelectorAll('.total');
    let overallTotal = 0;

    totalFields.forEach(function(field) {
        overallTotal += parseFloat(field.value) || 0;
    });

    document.getElementById('overall-total').value = overallTotal;
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_laravel\apotek-laravel8-main\resources\views/data/transaction/add.blade.php ENDPATH**/ ?>