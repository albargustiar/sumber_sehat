<?php $__env->startSection('title', 'Data Drug'); ?>
<?php $__env->startSection('subtitle', 'Detail Drug'); ?>
<?php $__env->startSection('content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4">
	<div class="card-header d-flex">
		<a class="btn btn-secondary" href="/drug">back</a>
		<a class="btn btn-success mx-2" href="/drug/edit/<?php echo e($drug->id); ?>">edit</a>
		<form action="/drug/delete/<?php echo e($drug->id); ?>" method="post">
			<?php echo method_field("delete"); ?>
			<?php echo csrf_field(); ?>
			<button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?');">delete</button>
		</form>
	</div>
	<div class="card-body">
		<div class="row">
			<ul class="list-group col-md-2 font-weight-bolder">
				<li class="list-group-item">Code</li>
				<li class="list-group-item">Supplier ID</li>
				<li class="list-group-item">Name Drug</li>
				<li class="list-group-item">Producer</li>
				<li class="list-group-item">Stock</li>
				<li class="list-group-item">Price</li>
				<li class="list-group-item">Created At</li>
				<li class="list-group-item">Updated At</li>
			</ul>
			<ul class="list-group col-md-5">
				<li class="list-group-item"><?php echo e($drug->code); ?></li>
				<li class="list-group-item"><?php echo e($drug->supplier_id); ?></li>
				<li class="list-group-item"><?php echo e($drug->name_drug); ?></li>
				<li class="list-group-item"><?php echo e($drug->producer); ?></li>
				<li class="list-group-item"><?php echo e($drug->stock); ?></li>
				<li class="list-group-item"><?php echo e($drug->price); ?></li>
				<li class="list-group-item"><?php echo e($drug->created_at); ?></li>
				<li class="list-group-item"><?php echo e($drug->updated_at); ?></li>
			</ul>
			<img width="200" height="200" src="<?php echo e(asset('storage/' . $drug->icon)); ?>" alt="<?php echo e($drug->name_drug); ?>">
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_laravel\apotek-laravel8-main\resources\views//data/drug/show.blade.php ENDPATH**/ ?>